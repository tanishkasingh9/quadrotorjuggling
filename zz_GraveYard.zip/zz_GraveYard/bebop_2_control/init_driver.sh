source devel/setup.bash
roslaunch bebop_driver bebop_node.launch
