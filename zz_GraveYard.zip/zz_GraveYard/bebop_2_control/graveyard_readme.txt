This is graveyard code as we could not figure out how to add urdf to parrot bebop 2 simulator.
This code works only for controlling bebop. 

Instructions:

OS: Ubuntu 16.04, ros: kinetic
    Make sure you have ros sphinx(for simulation of parrot bebop 2: https://developer.parrot.com/docs/sphinx/installation.html)
    Go to /opt/parrot-sphinx/usr/share/sphinx/drones/bebop2_local.drone and delete line containing 'stolen_interface's
    Run the setup.sh file to create your catkin workspace
    Run init_driver.sh in a new terminal to init bebop 2 drivers
    Run simulate_quad.sh to start sphinx
    Run control_quad.sh to control the quadcopter with your keyboard

