mkdir -p ./bebop_control/src && cd ./bebop_control/
catkin init
git clone https://github.com/AutonomyLab/bebop_autonomy.git src/bebop_autonomy
git clone https://github.com/ros-teleop/teleop_twist_keyboard src/teleop_twist_keyboard
cd src/teleop_twist_keyboard/
git apply ../../../teleop.diff
cd ../bebop_autonomy
git apply ../../../bebop_autonomy.diff
cd ../..
rosdep update
rosdep install --from-paths src -i
catkin_make
cd ..
mv control_quad.sh init_driver.sh simulate_quad.sh start_firmwared.sh ball_world_final model.config model.sdf bebop_control/
