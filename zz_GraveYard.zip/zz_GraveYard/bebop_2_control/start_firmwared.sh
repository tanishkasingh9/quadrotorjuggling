sudo systemctl start firmwared.service
sudo firmwared
